// import 'package:flutter/material.dart';


// import '../core/util/app_assets.dart';
// import '../features/home/lighting/lighting_container.dart';

// class LocalNotification extends StatelessWidget {
//   const LocalNotification({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.green,
//       body: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           LightingContainer(
//             backgroundColor: Colors.red,
//             backgroundImage: Assets.assetsImagesActiveWavesBlue,
//             trackColor: Color(0xffDFE6F1),
//             thumb1Color: Color(0xff705CED),
//             thumb2Color: Color(0xff705CED),
//           )
//           //  ClipRRect(
//           //    borderRadius: BorderRadius.circular(20),

//           //    child: TextButton(onPressed: () {

//           //    },
//           //    child:const Text("Go ToPage TWo")
//           //    ),
//           //  ),
//         ],
//       ),
//     );
//   }
// }
