class Routs{
   static const routSplashScreen = "/";
  static const routOnbourdingScreen = "/OnbourdingScreen";
  static const routLoginScreen = "/LoginScreen";
  static const routRegisterScreen = "/RegisterScreen";
   static const routForgetPasswordScreen = "/ForgetPassword";
  static const routHomeScreen = "/HomePage";
   static const routIconNavigation = "/NavigationIcon";



  }