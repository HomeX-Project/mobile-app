abstract class AppStrings {
  static const String continueText = "continue";
  static const String getStarted = "Get started";
  static const String skip = "Skip";
  static const String off = "Off";
  static const String on = "On";
}
