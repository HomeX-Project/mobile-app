abstract class AppStrings {
  static const String continueText = "continue";
  static const String getStarted = "Get started";
  static const String skip = "Skip";
  static const String dontHaveAcount = " Already have an account? ";
  static const String doYouHaveAcount = " Do you have account ?";
  static const String signUp = "Sign Up";
   static const String signIn = "Sign In";
      static const String lableTextPassword = "Password";
  static const String lableTextemai = "Email Adress";   
}
