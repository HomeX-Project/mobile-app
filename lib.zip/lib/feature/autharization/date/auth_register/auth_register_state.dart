class AppRegisterState{}
class AppInitialState extends AppRegisterState{}
class AppRegisterLoadedState extends AppRegisterState{}
class AppRegisterSuccessState extends AppRegisterState{}
class AppRegisterErrorState extends AppRegisterState{}
class ObscurePasswordTextUpdateState extends AppRegisterState{}
