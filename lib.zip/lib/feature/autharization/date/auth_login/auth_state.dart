class AppLoginState {}

class AppLoginInatialState extends AppLoginState {}

class AppLoginLoadingState extends AppLoginState {}

class AppLoginSuccessState extends AppLoginState {}

class AppLoginErrorState extends AppLoginState {
  
}
class ChangeModePassword extends AppLoginState {
  
}

