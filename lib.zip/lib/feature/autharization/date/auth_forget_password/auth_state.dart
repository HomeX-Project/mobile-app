class AppForgetPasswordState {}

class InitialState extends AppForgetPasswordState {}

class LoadedState extends AppForgetPasswordState {}

class AppSuccessForgetPasswordState extends AppForgetPasswordState {}

class AppErrorForgetPasswordState extends AppForgetPasswordState {
  
}
